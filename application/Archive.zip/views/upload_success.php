<?php
echo $data;

?>