
</div>

<!-- Javascript -->
<script src="<?php echo base_url(); ?>assets/bundles/libscripts.bundle.js"></script>    
<script src="<?php echo base_url(); ?>assets/bundles/vendorscripts.bundle.js"></script>

<script src="<?php echo base_url(); ?>assets/bundles/datatablescripts.bundle.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jquery-datatable/buttons/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jquery-datatable/buttons/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jquery-datatable/buttons/buttons.colVis.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jquery-datatable/buttons/buttons.html5.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/jquery-datatable/buttons/buttons.print.min.js"></script>

<script src="<?php echo base_url(); ?>assets/vendor/sweetalert/sweetalert.min.js"></script> <!-- SweetAlert Plugin Js --> 

<!-- Confirm JS -->
<script src="<?php echo base_url(); ?>assets/js/jquery-confirm.min.js"></script>


<script src="<?php echo base_url(); ?>/assets/disabler-enabler/enabler.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>/assets/disabler-enabler/disabler.js" type="text/javascript"></script>

<script src="<?php echo base_url(); ?>assets/bundles/mainscripts.bundle.js"></script>
<script src="<?php echo base_url(); ?>assets/js/shi.js"></script>
</body>
</html>
