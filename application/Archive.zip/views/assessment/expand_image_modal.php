
						<img id="blah" src="<?php if(!empty($image_details->image)) { echo base_url().'uploads/'.$image_details->image; } ?>" alt=""/>