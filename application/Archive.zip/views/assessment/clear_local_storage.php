<script type="text/javascript">
	localStorage.clear();

</script>
<?php 
redirect('assessment/view');
?>